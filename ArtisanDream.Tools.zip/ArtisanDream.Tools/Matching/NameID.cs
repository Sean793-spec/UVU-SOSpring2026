﻿using UnityEngine;

[CreateAssetMenu(menuName = "ScriptableObjects/NameId")]
public class NameId : ScriptableObject
{
}