using UnityEngine;
[CreateAssetMenu]
public class Id: ScriptableObject
{
}