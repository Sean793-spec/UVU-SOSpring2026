using UnityEngine;

public class SimpleIDBehaviour : MonoBehaviour
{
    public Id id;
}