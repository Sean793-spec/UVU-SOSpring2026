using UnityEngine;

namespace ArtisanDream.Tools.Bahaviours
{
    public class ProgramBehavior : MonoBehaviour
    {
        public void Start()
        {
            Debug.Log("Hello World!");
        }
    }
}