﻿using UnityEngine;

[CreateAssetMenu(menuName = ("Character Patterns/ Hold"))]
public class CharacterHold : CharacterPattern
{
    public override void Move(CharacterController controller)
    {
        
    }
}