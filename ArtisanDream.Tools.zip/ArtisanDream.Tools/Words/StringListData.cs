using System.Collections.Generic;
[System.Serializable]
class StringListData
{
    public List<string> stringList;
}